
Note: 
Backup your files and database before upgrade.

Updation Steps:

1. Goto this folder: "/Upgrade/v1.4 to v1.5/Upload"

2. Use your Server FTP or File Manager application on your server. 

3. Now, replace old files directly with new files present at upload directory.

You have done the work! 