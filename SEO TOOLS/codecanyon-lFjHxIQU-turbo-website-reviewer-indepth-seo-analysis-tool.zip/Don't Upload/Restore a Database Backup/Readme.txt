1. Upload "restore-db.php" file into root directory of script.

2. Also, upload your database backup file and rename as "restore-db.sql"

3. Execute the file by visiting below URL 
"http://your_domain_name.com/restore-db.php"

