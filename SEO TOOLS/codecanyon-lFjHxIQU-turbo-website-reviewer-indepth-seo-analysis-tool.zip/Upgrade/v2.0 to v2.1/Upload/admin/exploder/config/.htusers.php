<?php
            if( !defined( '_JEXEC' ) && !defined( '_VALID_MOS' ) ) die( 'Restricted access' );
            
            $GLOBALS["users"]=array(
            	array("rainbowphp","598857c52a29dbd8209b0907deb5c1216239798",empty($_SERVER['DOCUMENT_ROOT'])?realpath(dirname(__FILE__).'/..'):$_SERVER['DOCUMENT_ROOT'],"http://localhost",1,"",7,1),
            ); ?>
            