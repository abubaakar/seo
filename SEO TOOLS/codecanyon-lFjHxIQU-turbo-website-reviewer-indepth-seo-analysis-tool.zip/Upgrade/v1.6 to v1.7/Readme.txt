
Note: 
Backup your files and database before upgrade.

Updation Steps:
1. Delete this folder from your server completely
->  "/core/library/filemanager/"

2. Goto this folder: "/Upgrade/v1.6 to v1.7/Upload"

3. Use your Server FTP or File Manager application on your server. 

4. Now, replace old files directly with new files present at upload directory.

You have done the work!