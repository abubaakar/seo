<?php

defined('APP_NAME') or die(header('HTTP/1.0 403 Forbidden'));

if(!defined('SEO_ADDON_TOOLS')){
    $controller = "error";
    require(CON_DIR. $controller . '.php');
}

/*
 * @author Balaji
 * @name: A to Z SEO Tools - PHP Script
 * @copyright � 2017 ProThemes.Biz
 *
 */

