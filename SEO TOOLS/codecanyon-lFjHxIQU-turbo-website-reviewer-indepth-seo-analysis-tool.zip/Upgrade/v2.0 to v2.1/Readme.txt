
Note: 
Backup your files and database before upgrade.

Updation Steps:

1) Delete this folder from your server completely
->  "/admin/exploder/"

2) Goto this folder: "/Upgrade/v2.0 to v2.1/Upload"

3) Use your Server FTP or File Manager application on your server. 

4) Now, replace old files directly with new files present at upload directory.

You have done the work!


Internal link support and 50x SEO tools addon pack users:
Download again addon ZIP package from purchased website and update into latest addon files.