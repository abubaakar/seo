
Script Name: 50x SEO Tools Pack for Turbo Website Reviewer
Version: 2.8
Developed by Balaji
Contact US for Support: rainbowbalajib@gmail.com

List of SEO Tools:

Article Rewriter
Plagiarism Checker
Backlink Maker
Meta Tag Generator
Meta Tags Analyzer
Keyword Position Checker
Robots.txt Generator
XML Sitemap Generator
Backlink Checker
Alexa Rank Checker
Word Counter
Online Ping Website Tool
Link Analyzer
PageRank Checker
My IP Address
Keyword Density Checker
Google Malware Checker
Domain Age Checker
Whois Checker
Domain into IP
Dmoz Listing Checker
URL Rewriting Tool
www Redirect Checker
Mozrank Checker
URL Encoder / Decoder

Server Status Checker
Webpage Screen Resolution Simulator
Page Size Checker
Reverse IP Domain Checker
Blacklist Lookup
AVG Antivirus Checker
Link Price Calculator
Website Screenshot Generator
Domain Hosting Checker
Get Source Code of Webpage
Google Index Checker
Website Links Count Checker
Class C Ip Checker
Online Md5 Generator
Page Speed Checker
Code to Text Ratio Checker
Find DNS records
What is my Browser
Email Privacy
Google Cache Checker
Broken Links Finder
Search Engine Spider Simulator
Keywords Suggestion Tool
Domain Authority Checker
Page Authority Checker

Requirements:
- Turbo Website Reviewer

Installation:
1. Login into Admin Panel
2. Now select, Admin Panel -> Addons -> Install Addons
3. Click browse button and select addon package. 

Change Log:

Version 2.8
- Updated: Backlink Checker
- Updated: Alexa Helper

Version 2.7
- Updated: AJAX Controller
- Updated: Keyword Position Checker

Version 2.6
- Updated: AJAX Controller
- Updated: Keyword Position Checker
- Updated: Addon installation system with PHP 8 support
- Updated: Alexa helper library
- Updated: Host Info library
- Improved: Loading speed of application
- Fixed: Some minor bugs

Version 2.5
- Updated: AJAX Controller
- Updated: Keyword Position Checker

Version 2.4
- Updated: AJAX Controller (Mobile friendly checker addon issue)
- Updated: Google Pagespeed Insights Checker 
- Fixed: Some minor bugs

Version 2.3
- Updated: WHOIS Class
- Updated: Keyword Position Checker
- Updated: Google Index Checker
- Fixed: Some minor bugs

Version 2.2
- Updated: WHOIS Class
- Updated: Keyword Position Checker
- Updated: Google Index Checker
- Updated: Blacklist Lookup database
- Fixed: Google Maps Issue at "My IP Address" tool
- Fixed: Some minor bugs

Version 2.1
- Changes in XML Sitemap Helper
- Minor bug fixes

Version 2.0
- Added "AtoZ SEO Tools v2.0" tools support.

Version 1.0
- Initial release