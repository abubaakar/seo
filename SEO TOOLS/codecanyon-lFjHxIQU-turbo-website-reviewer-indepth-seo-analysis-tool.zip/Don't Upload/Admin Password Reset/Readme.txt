1. Upload "reset.php" file into root directory of script.

2. Execute the file by visiting URL 
"http://your_domain_name.com/reset.php"

3. Now try default credentials 
Admin Username: demo@prothemes.biz
Admin Password: password