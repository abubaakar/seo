

Note: Backup your files and database before upgrade.

Updation Steps:

1. Goto this folder: "/Upgrade/v1.0 to v1.1/Upload"

2. Use your Server FTP or File Manager application on your server. 

3. Now, replace old files directly with new files present at upload directory.

4. After successful file upload, just visit the "upgrade.php" file link on your browser and complete your updation.

"http://your-domain.com/upgrade.php"

You have done the work! 