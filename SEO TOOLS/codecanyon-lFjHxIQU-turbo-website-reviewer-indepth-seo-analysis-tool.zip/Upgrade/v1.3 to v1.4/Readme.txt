

Note: 

i) Backup your files and database before upgrade.
ii) This upgrade have some changes on interface part. So you're theme customizations may be affected.

Updation Steps:

1. Goto this folder: "/Upgrade/v1.3 to v1.4/Upload"

2. Use your Server FTP or File Manager application on your server. 

3. Now, replace old files directly with new files present at upload directory.

You have done the work! 