<?php
defined('ROOT_DIR') or die(header('HTTP/1.0 403 Forbidden'));

/*
 * @author Balaji
 * @name: Rainbow PHP Framework
 * @copyright 2019 ProThemes.Biz
 *
 */
 
// --- Application Settings ---

//Define Application Name
define('APP_NAME','Turbo Website Reviewer');
define('HTML_APP_NAME','<b>Turbo</b> Reviewer');

//Define Version Number of Application
define('VER_NO','1.8');

//Define Native App Name
define('NATIVE_APP_NAME','');

//Define Native Sign
define('NATIVE_SIGN','');

//Define Native Application Sign
define('NATIVE_APP_SIGN','');

//Set Default Controller
define('CON_MAIN','main');

//Set Default Error Controller
define('CON_ERR','error');